#!/bin/bash
#
# backup_full.sh
# Backup de un directorio en formato .tar.gz
# Uso: /opt/scripts/backup_full.sh <origen> <destino>
#

# ===== Variables =====
ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)

# ===== Funciones =====
ayuda () {
    echo "Uso: $0 <origen> <destino>"
    echo " "
    echo "Genera un backup comprimido del directorio <origen>"
    echo "y lo guarda en <destino> como <nombre>_bkp_AAAAMMDD.tar.gz"
    echo " "
    echo "Ejemplo: $0 /var/log /backup_dir"
    echo "Genera:  /backup_dir/log_bkp_$FECHA.tar.gz"
    echo " "
    echo "Opciones:"
    echo "  -help   Muestra esta ayuda"
}

# ===== Opcion de ayuda =====
if [[ "$1" == "-help" ]]; then
    ayuda
    exit 0
fi

# ===== Validar cantidad de argumentos =====
if [[ $# -ne 2 ]]; then
    echo "Error: se necesitan 2 argumentos (origen y destino)."
    echo "Para ver la ayuda: $0 -help"
    exit 1
fi

# ===== Validar origen =====
if [[ ! -d $ORIGEN ]]; then
    echo "Error: el origen $ORIGEN no existe o no es un directorio."
    exit 2
fi

# Si el origen es una particion del fstab, tiene que estar montada
if grep -qw "$ORIGEN" /etc/fstab && ! mountpoint -q $ORIGEN; then
    echo "Error: $ORIGEN no esta montado."
    exit 3
fi

# ===== Validar destino =====
if [[ ! -d $DESTINO ]]; then
    echo "Error: el destino $DESTINO no existe."
    exit 4
fi

if ! mountpoint -q $DESTINO; then
    echo "Error: $DESTINO no esta montado. No se hace el backup."
    exit 5
fi

# ===== Backup =====
NOMBRE=$(basename $ORIGEN)
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

tar -czf $DESTINO/$ARCHIVO -C $(dirname $ORIGEN) $NOMBRE

if [[ $? -eq 0 ]]; then
    echo "Backup OK: $DESTINO/$ARCHIVO"
else
    echo "Error: fallo el backup de $ORIGEN"
    exit 6
fi

